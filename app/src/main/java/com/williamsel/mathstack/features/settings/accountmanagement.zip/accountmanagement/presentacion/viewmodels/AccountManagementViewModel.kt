package com.williamsel.mathstack.features.settings.accountmanagement.presentacion.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.williamsel.mathstack.features.settings.accountmanagement.presentacion.screens.AccountManagementUiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AccountManagementViewModel @Inject constructor() : ViewModel() {

    private val _uiState = MutableStateFlow(AccountManagementUiState())
    val uiState: StateFlow<AccountManagementUiState> = _uiState.asStateFlow()

    init {
        loadAccountInfo()
    }

    private fun loadAccountInfo() {
        // Placeholder: En un escenario real, esto vendría de un UseCase
        _uiState.update { 
            it.copy(
                username = "Estudiante",
                email = "estudiante@email.com"
            )
        }
    }

    fun onUsernameChange(newUsername: String) {
        _uiState.update { it.copy(username = newUsername) }
    }

    fun onSaveChanges() {
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, errorMessage = null) }
            // Simular guardado
            kotlinx.coroutines.delay(1000)
            _uiState.update { 
                it.copy(
                    isSaving = false, 
                    successMessage = "Cambios guardados correctamente"
                )
            }
        }
    }

    fun onDeleteAccount() {
        viewModelScope.launch {
            _uiState.update { it.copy(isDeleting = true, errorMessage = null) }
            // Simular eliminación
            kotlinx.coroutines.delay(1500)
            _uiState.update { it.copy(isDeleting = false, accountDeleted = true) }
        }
    }

    fun onErrorDismissed() = _uiState.update { it.copy(errorMessage = null) }
    fun onSuccessDismissed() = _uiState.update { it.copy(successMessage = null) }
}
